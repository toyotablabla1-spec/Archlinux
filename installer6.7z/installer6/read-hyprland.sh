# a = hyprland from https://www.youtube.com/watch?v=azGR2P5aco0

#yay -S hyprshot wlogout && sudo pacman -S wofi kitty freetype2 zsh git hyprlock hyprpaper waybar ttf-font-awesome otf-font-awesome ttf-jetbrains-mono obsidian pavucontrol feh ranger thunar meson nwg-look papirus-icon-theme fastfetch file powerline-fonts inetutils ttf-font-awesome otf-font-awesome ttf-jetbrains-mono neovim code ttf-dejavu bluez bluez-utils blueman telegram-desktop vlc fastfetch && cd ~/Documents && git clone https://github.com/vinceliuice/Graphite-gtk-theme.git && git clone https://github.com/itRoy-pentest/RoyHyprland.git && cd RoyHyprland && cp -r kitty waybar wlogout wofi hypr fastfetch ~/.config && cd ~/Documents && cd Graphite-gtk-theme && ./install.sh && sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)" && git clone --depth=1 https://github.com/romkatv/powerlevel10k.git "${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}/themes/powerlevel10k" && git clone https://github.com/zsh-users/zsh-autosuggestions ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions && git clone https://github.com/zsh-users/zsh-syntax-highlighting.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting




# b = hyde from
#git clone --depth 1 https://github.com/HyDE-Project/HyDE ~/HyDE && cd ~/HyDE/Scripts && ./install.sh pkg_user.lst
# c = hyprland google style from https://www.youtube.com/watch?v=VlAOmBOk7zw
cd ~/.cache && git clone https://github.com/end-4/dots-hyprland && cd dots-hyprland && ./setup install


